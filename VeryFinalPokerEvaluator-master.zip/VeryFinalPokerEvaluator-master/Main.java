
public class Main {
	// constants
	final static String[]ranks = {"A","2","3","4","5","6","7","8","9","T","J","Q","K"};
	final static char[]suits= {'D','S','C','H'};

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(ranks);
		System.out.println(suits);
	}

}
