import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class MainTest {

	@Before
	public void setUp() throws Exception {
			testMain();
	}

	@Test
	public void testMain() {
		//fail("Not yet implemented");
		final String[]ranks = {};
		final char[]suits= {};
		
	}

}
