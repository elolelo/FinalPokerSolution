# Inclusitivity Assignment
coding assignment of Poker Cards


Language used: Java 8
